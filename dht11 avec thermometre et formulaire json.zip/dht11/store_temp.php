<?php

$filename_temperature = "data.txt" ;

if (isset($_POST["temperature"])) {
    $temperature = $_POST["temperature"] ;
    $op = file_put_contents($filename_temperature, $temperature) ;
    if (! $op) {
        echo "store error" ;
    }
} else {
    echo "data error" ;
}
?>
